export class Certificate{
    certificate!:string;
    status!:string;
    type!:string;
}