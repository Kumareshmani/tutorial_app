export class WeekMeetModel{
    meeting_link!:string;
    date!:string;
    id!:number;
    day!:number;
    month!:number;
    year!:number;
    hour!:number;
    minutes!:number;
    seconds!:number;
    remaining_seconds!:number;
}