export class ProfileModel{
    name!:string;
    email!: string;
    image!:string;
    notification!:number;
}