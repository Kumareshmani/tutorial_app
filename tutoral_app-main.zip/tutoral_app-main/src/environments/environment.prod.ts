export const environment = {
  production: true,
  ip:""
};
