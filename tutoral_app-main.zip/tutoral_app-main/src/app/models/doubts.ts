export class CourseDoubts{
    name!:string;
    image!:string;
    question!:string;
    answer!:string;
    date!:string;
}