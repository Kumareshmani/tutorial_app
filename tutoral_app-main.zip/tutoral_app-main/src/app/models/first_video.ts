export class FirstVideo{
    id!:number;
    title!: string;
    description!:string;
    video!:string;
    thumbnail!:string;
}