export class AboutCourse{
    requirements!:Array<string>;
    benefits!:Array<string>;
    authors!:Array<string>;
}