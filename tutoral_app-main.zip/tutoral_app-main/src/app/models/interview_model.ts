export class InterviewModel{
    meeting_link!:string;
    date!:string;
    course_id!:number;
    course_name!:string;
    status!:string;
    day!:number;
    month!:number;
    hour!:number;
    year!:number;
    minutes!:number;
    seconds!:number;

}