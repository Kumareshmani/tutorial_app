

export class HomeBanners {
    id!:number;
    image!:string;
    link!:string;
}

