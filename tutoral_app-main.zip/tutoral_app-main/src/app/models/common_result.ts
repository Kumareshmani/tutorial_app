export class ResultData{
    result!:string;
    result_code!: string;
    description!:string;
}