export class RazorpayResult{
    key!:  string;
    name!:  string;
    email!:  string;
    phone!:  string;
    currency!: string;
    amount!: number;
}